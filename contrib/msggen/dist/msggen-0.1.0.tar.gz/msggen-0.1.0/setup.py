# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['msggen', 'msggen.gen', 'msggen.utils']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['msggen = msggen.__main__:run']}

setup_kwargs = {
    'name': 'msggen',
    'version': '0.1.0',
    'description': 'A utility to transform wire messages and JSON-RPC messages to arbitrary target languages.',
    'long_description': 'None',
    'author': 'Christian Decker',
    'author_email': 'decker@blockstream.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
